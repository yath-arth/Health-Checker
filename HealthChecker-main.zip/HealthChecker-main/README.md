# Health-Checker
I built several ml models to predict the chances of getting a disease.
Katasets are downloaded from kaggle 
currently i have made cancer prediction,diabeters prediction, Heart-Attack prediction,Kidney_disease prediction and Heart disease prediction and also working on liver disease prediction 
